TEZBOOKS  ·  by Elite Kaiiser
Retail & wholesale billing, GST, inventory, barcodes — works offline on your shop computer.

────────────────────────────────────────
1. INSTALL ON THE MAIN SHOP COMPUTER (Windows 10 or 11)
────────────────────────────────────────
  • Double-click "TezBooks 1.7.0 Setup.exe". Windows may say "Windows protected your PC"
    (the program is new and not yet code-signed): click  More info → Run anyway.
  • TezBooks Setup opens: Welcome → Where TezBooks runs → Options → Install → Finish.
    - Choose "This is the MAIN computer" for the computer that keeps the shop's data.
    - Options: start with Windows, let phones and other counters connect (Windows asks
      for permission once), Desktop icon.
    - An older TezBooks is updated; your bills, items, customers and settings stay.
  • The billing window opens. Enter shop name, your name and a PIN. The 7-day free
    trial starts.
  • Moving from Vyapar, Marg, Busy, Tally or Excel? Settings → Import from another
    software. Just looking? Settings → Load sample shop (clear it before real billing).

  Data is kept in:  %APPDATA%\TezBooks   (backups in its "backups" folder,
  one per day, last 30 kept). Add a pen-drive or Google Drive folder in
  Settings → Program → Extra backup folder for a second copy.

────────────────────────────────────────
2. LICENCE
────────────────────────────────────────
  • Settings → Licence shows this computer's code (like ABCD-EFGH-JKLM-N).
  • Send the code to Elite Kaiiser. You will get a licence key (starts with TB1-).
  • Paste the key in Settings → Licence → Activate key.
  • Easier: keep the computer on the internet. Once Elite Kaiiser approves your shop the licence
    arrives and starts by itself (or press Settings → Licence → Check now).
  • The licence is checked online when the program starts and every few hours. It sends only:
    the computer code, shop name, phone, address/city, GSTIN, owner's name, program version
    and how many bills and items you have — never your bills, customers or prices.
    Without internet the program keeps working; Elite Kaiiser may ask for an online check
    every few days.
  • If the licence ends, billing pauses but all records stay viewable and exportable.

────────────────────────────────────────
3. MORE COUNTERS, PHONES AND TABLETS
────────────────────────────────────────
  • Keep the main computer on and TezBooks running.
  • Settings → Program & counters shows the address (e.g. http://192.168.1.20:8770/) and a QR.
  • Another Windows counter: run the same Setup and choose "This is ANOTHER counter", type
    the main computer's address and press Check. It gets its own TezBooks icon.
  • Phones and tablets on the SAME Wi-Fi: open that address in Chrome / Safari (or scan the
    QR). Log in with the staff PIN. Browser menu → "Add to Home screen" for an app icon.
  • The number of counters at the same time depends on your licence.

────────────────────────────────────────
4. PRINTING AND EMAIL
────────────────────────────────────────
  • Settings → Printers: press "Find printers" (and "Find network printers" for printers on
    the shop Wi-Fi). Choose the printer for counter bills (80 or 58 mm), for A4 invoices
    (and how many copies) and for barcode labels. "Print straight to these printers" prints
    without a print window. If a printer is off, the bill is kept and you get "Print again".
  • A new printer plugged in while TezBooks runs: TezBooks asks "Use it?".
  • A4 bill layout: Settings → Billing rules → Classic GST, Modern, or Two copies on one sheet;
    tick logo, HSN, tax summary, bank & UPI QR, amount in words, signature.
  • Cash drawer: tick "Open the cash drawer on cash bills" (drawer plugged into the receipt printer).
  • Email: Settings → Send bills by email. For Gmail, make an "App password" in your Google
    account (Security → 2-Step Verification → App passwords) and paste it. Then use "✉ Email"
    on any bill, or tick "Email the bill automatically after saving". Bills go as a PDF from
    your own address. Without internet, emails wait and go when it is back.
    Invoices shows Sent / Waiting / Failed for each bill. Add customers' emails in Customers.
  • Save PDF: on any bill.
  • Barcode labels: Inventory → Barcode & QR maker.
  • Customer screen: on the bill screen click "Customer screen" and drag that window
    to the second monitor facing the customer.

────────────────────────────────────────
5. SCANNERS
────────────────────────────────────────
  • Any USB or Bluetooth barcode / QR scanner works (keyboard mode, ending with
    Enter or Tab). Scan on any screen.

────────────────────────────────────────
6. CLOSING / UPDATING
────────────────────────────────────────
  • Closing the billing window keeps the program running for other counters.
    To stop it fully: Settings → Program → Close program.
  • Updates come by themselves over the internet when Elite Kaiiser sends them: TezBooks
    downloads the new version, checks it is genuine, backs up your data, and installs it at
    night when the shop is closed (or the next time TezBooks is opened). The owner can also
    press "Install now".
  • Or run the new Setup yourself; your data and settings are kept.
  • To uninstall: Windows Settings → Apps → TezBooks → Uninstall.
    Your shop data folder is kept; delete it yourself only if you are sure.

────────────────────────────────────────
7. NEW IN 1.1
────────────────────────────────────────
  Hindi & Gujarati screens · import from Vyapar/Marg/Busy/Tally/Excel · Tally export ·
  GSTR-3B summary · e-invoice & e-way bill files · returns to supplier (debit notes) ·
  delivery challans · due dates & ageing · salesman orders & commission · price list on
  WhatsApp · customer screen · cash drawer & direct label printing · categories &
  brands · offers, combos & coupons · alerts & activity log · item profit, dead stock,
  staff and P&L reports · shops/godowns with stock transfer · sample shop · help pages.

────────────────────────────────────────
8. NEW IN 1.2
────────────────────────────────────────
  • Accounts: day book, ledgers, receipt/payment/contra/journal vouchers, trial
    balance, profit & loss and balance sheet, built automatically from your bills,
    purchases, payments and expenses.
  • Bank reconciliation: import your bank statement (CSV/Excel) and match it with
    your entries; most lines match automatically.
  • GSTR-2B check: load the 2B file from the GST portal (JSON or Excel) and see which
    supplier bills match, differ, or are missing, with WhatsApp reminders to suppliers.
  • Online backup: an encrypted copy of your shop data is kept online every day.
    WRITE DOWN THE RECOVERY CODE and keep it safe. Without it nobody, including
    Elite Kaiiser, can open or restore your backup. To restore on a new computer:
    first screen → "New computer? Restore from online backup".
  • Payment links: send a UPI/card payment link to a customer on WhatsApp. When the
    customer pays, the payment is entered by itself. Needs your own Razorpay account
    (Settings → Online payments); Razorpay charges its own fee.
  • Owner's phone page: see today's sales, cash and dues on your phone
    (Settings → Owner's phone dashboard).

────────────────────────────────────────
9. NEW IN 1.3
────────────────────────────────────────
  • Quick-add buttons for everyday items (★ above the bill; owner/manager chooses them).
  • Bigger total. Cash notes (exact, ₹50, ₹100, ₹500, ₹2,000…) and a green "Return change".
  • Reprint the last bill: button or F10.
  • Customer's old balance shown with a "Collect" button; last price given to that customer
    shown on each item; "only N left" when stock is low; Undo after removing an item.
  • Cashiers need the owner's or a manager's PIN for a discount above the limit you set
    (Settings → Credit, alerts & branches).
  • Text size: A / A / A at the bottom of the menu. Shop logo on screen and on bills
    (Settings → Business details).
  • New look: shop name and titles in Cinzel capitals, text in Montserrat. A welcome screen
    with your shop name, date and today's bill count before login, and a Home screen after
    login: today's sales, cash, dues, quick start buttons and what needs attention
    (cashiers see only their own bills).
  • Forgot the owner PIN? On the main computer: login screen → "Forgot owner PIN?" → use the
    online-backup recovery code, or a one-time code from Elite Kaiiser.

────────────────────────────────────────
10. NEW IN 1.7
────────────────────────────────────────
  • Bills on WhatsApp as a link: the customer opens the full bill on their phone, saves it as
    PDF and pays the balance by UPI in one tap. Udhaar reminders carry a link listing all
    unpaid bills with a "Pay by UPI" button. Links are locked — only someone with the link
    can read the bill. (Settings → Bills on WhatsApp)
  • UPI at the counter: when a bill is UPI, a QR for the exact amount opens on the screen;
    press "Payment received" to save, or "Not paid — give udhaar". (Settings → UPI bills)
  • GSTR-1 file for the GST portal: Reports → GST & accounts → GSTR-1 file for the portal.
    Pick the month, check the list, upload at Returns → GSTR-1 → Prepare offline. Includes
    the B2B / B2C HSN summary and documents issued. GSTR-3B summary now also shows table
    3.2 (sales to unregistered buyers in other states).

────────────────────────────────────────
NEW IN 1.6
────────────────────────────────────────
  • Branches: run TezBooks at every shop of your business and keep them in step over the
    internet (Settings → Branches). Items, prices, customers, udhaar, suppliers and offers
    are shared; each shop sells from its own stock and has its own bill numbers. Send stock
    to another shop (Inventory → Transfer) — it is added there when they press Received.
    Reports → All branches shows every shop side by side. Everything is locked with your
    business key before it leaves the computer.
  • Online orders: your own order page, tezbooks.com/o/your-shop (Online orders in the menu).
    Customers order on their phone for home delivery or pickup and pay cash or UPI when they
    get it. New orders ring at the counter; accept, make the bill in one tap, and send
    updates on WhatsApp. Set delivery charge, free delivery above, minimum order, and pause
    any time. Hide an item: Products → item → Online orders page → Hide.

────────────────────────────────────────
NEW IN 1.5
────────────────────────────────────────
  1.5.1: download the free trial from tezbooks.com; quote requests from the website reach
         Elite Kaiiser directly.
  • TezBooks Setup window (main computer or another counter).
  • Printers: find printers, choose a printer for bills, A4 and labels, print without a window.
  • Three A4 bill layouts; long bills continue neatly onto more pages.
  • Email bills as PDF from your own email; Save PDF.
  • Updates over the internet, checked and installed by themselves.

Mac:  use TezBooks-AppleSilicon (M1/M2/M3) or TezBooks-Intel.
      First time: right-click → Open. Data: ~/Library/Application Support/TezBooks
Linux: ./tezbooks      Data: ~/.tezbooks

© Elite Kaiiser. All rights reserved.
