TEZBOOKS  ·  by Elite Kaiiser
Retail & wholesale billing, GST, inventory, barcodes — works offline on your shop computer.

────────────────────────────────────────
1. INSTALL ON THE MAIN SHOP COMPUTER (Windows 10 or 11)
────────────────────────────────────────
  • Double-click "TezBooks 2.1.0 Setup.exe". Windows may say "Windows protected your PC"
    (the program is new and not yet code-signed): click  More info → Run anyway.
  • TezBooks Setup opens: Welcome → Where TezBooks runs → Options → Install → Finish.
    - Choose "This is the MAIN computer" for the computer that keeps the shop's data.
    - Options: start with Windows, let phones and other counters connect (Windows asks
      for permission once), Desktop icon.
    - An older TezBooks is updated; your bills, items, customers and settings stay.
  • The billing window opens. Enter shop name, your name and a PIN. The 30-day free
    trial starts.
  • Moving from Vyapar, Marg, Busy, Tally or Excel? Settings → Import from another
    software. Just looking? Settings → Load sample shop (clear it before real billing).

  Data is kept in:  %APPDATA%\TezBooks   (backups in its "backups" folder,
  one per day, last 30 kept). Add a pen-drive or Google Drive folder in
  Settings → Program → Extra backup folder for a second copy.

────────────────────────────────────────
2. LICENCE
────────────────────────────────────────
  • Settings → Licence shows this computer's code (like ABCD-EFGH-JKLM-N).
  • Send the code to Elite Kaiiser. You will get a licence key (starts with TB2-; older TB1- keys still work).
  • Paste the key in Settings → Licence → Activate key.
  • Easier: keep the computer on the internet. Once Elite Kaiiser approves your shop the licence
    arrives and starts by itself (or press Settings → Licence → Check now).
  • The licence is checked online when the program starts and every few hours. It sends only:
    the computer code, shop name, phone, address/city, GSTIN, owner's name, program version
    and how many bills and items you have — never your bills, customers or prices.
    Without internet the program keeps working; Elite Kaiiser may ask for an online check
    every few days.
  • If the licence ends, billing continues for a few grace days (usually 7) with a red
    "renew" warning, then pauses. All records stay viewable, printable and exportable.

────────────────────────────────────────
3. MORE COUNTERS, PHONES AND TABLETS
────────────────────────────────────────
  • Keep the main computer on and TezBooks running.
  • Settings → Program & counters shows the address (e.g. http://192.168.1.20:8770/) and a QR.
  • Another Windows counter: run the same Setup and choose "This is ANOTHER counter", type
    the main computer's address and press Check. It gets its own TezBooks icon.
  • Phones and tablets on the SAME Wi-Fi: open that address in Chrome / Safari (or scan the
    QR). Log in with the staff PIN. Browser menu → "Add to Home screen" for an app icon.
  • The number of counters at the same time depends on your licence.

────────────────────────────────────────
4. PRINTING AND EMAIL
────────────────────────────────────────
  • Settings → Printers: press "Find printers" (and "Find network printers" for printers on
    the shop Wi-Fi). Choose the printer for counter bills (80 or 58 mm), for A4 invoices
    (and how many copies) and for barcode labels. "Print straight to these printers" prints
    without a print window. If a printer is off, the bill is kept and you get "Print again".
  • A new printer plugged in while TezBooks runs: TezBooks asks "Use it?".
  • A4 bill layout: Settings → Billing rules → Classic GST, Modern, or Two copies on one sheet;
    tick logo, HSN, tax summary, bank & UPI QR, amount in words, signature.
  • Cash drawer: tick "Open the cash drawer on cash bills" (drawer plugged into the receipt printer).
  • Email: Settings → Send bills by email. For Gmail, make an "App password" in your Google
    account (Security → 2-Step Verification → App passwords) and paste it. Then use "✉ Email"
    on any bill, or tick "Email the bill automatically after saving". Bills go as a PDF from
    your own address. Without internet, emails wait and go when it is back.
    Invoices shows Sent / Waiting / Failed for each bill. Add customers' emails in Customers.
  • Save PDF: on any bill.
  • Barcode labels: Inventory → Barcode & QR maker.
  • Customer screen: on the bill screen click "Customer screen" and drag that window
    to the second monitor facing the customer.

────────────────────────────────────────
5. SCANNERS
────────────────────────────────────────
  • Any USB or Bluetooth barcode / QR scanner works (keyboard mode, ending with
    Enter or Tab). Scan on any screen.

────────────────────────────────────────
6. CLOSING / UPDATING
────────────────────────────────────────
  • Closing the billing window keeps the program running for other counters.
    To stop it fully: Settings → Program → Close program.
  • Updates come by themselves over the internet when Elite Kaiiser sends them: TezBooks
    downloads the new version, checks it is genuine, backs up your data, and installs it at
    night when the shop is closed (or the next time TezBooks is opened). The owner can also
    press "Install now".
  • Or run the new Setup yourself; your data and settings are kept.
  • To uninstall: Windows Settings → Apps → TezBooks → Uninstall.
    Your shop data folder is kept; delete it yourself only if you are sure.

────────────────────────────────────────
7. NEW IN 1.1
────────────────────────────────────────
  Hindi & Gujarati screens · import from Vyapar/Marg/Busy/Tally/Excel · Tally export ·
  GSTR-3B summary · e-invoice & e-way bill files · returns to supplier (debit notes) ·
  delivery challans · due dates & ageing · salesman orders & commission · price list on
  WhatsApp · customer screen · cash drawer & direct label printing · categories &
  brands · offers, combos & coupons · alerts & activity log · item profit, dead stock,
  staff and P&L reports · shops/godowns with stock transfer · sample shop · help pages.

────────────────────────────────────────
8. NEW IN 1.2
────────────────────────────────────────
  • Accounts: day book, ledgers, receipt/payment/contra/journal vouchers, trial
    balance, profit & loss and balance sheet, built automatically from your bills,
    purchases, payments and expenses.
  • Bank reconciliation: import your bank statement (CSV/Excel) and match it with
    your entries; most lines match automatically.
  • GSTR-2B check: load the 2B file from the GST portal (JSON or Excel) and see which
    supplier bills match, differ, or are missing, with WhatsApp reminders to suppliers.
  • Online backup: an encrypted copy of your shop data is kept online every day.
    WRITE DOWN THE RECOVERY CODE and keep it safe. Without it nobody, including
    Elite Kaiiser, can open or restore your backup. To restore on a new computer:
    first screen → "New computer? Restore from online backup".
  • Payment links: send a UPI/card payment link to a customer on WhatsApp. When the
    customer pays, the payment is entered by itself. Needs your own Razorpay account
    (Settings → Online payments); Razorpay charges its own fee.
  • Owner's phone page: see today's sales, cash and dues on your phone
    (Settings → Owner's phone dashboard).

────────────────────────────────────────
9. NEW IN 1.3
────────────────────────────────────────
  • Quick-add buttons for everyday items (★ above the bill; owner/manager chooses them).
  • Bigger total. Cash notes (exact, ₹50, ₹100, ₹500, ₹2,000…) and a green "Return change".
  • Reprint the last bill: button or F10.
  • Customer's old balance shown with a "Collect" button; last price given to that customer
    shown on each item; "only N left" when stock is low; Undo after removing an item.
  • Cashiers need the owner's or a manager's PIN for a discount above the limit you set
    (Settings → Credit, alerts & branches).
  • Text size: A / A / A at the bottom of the menu. Shop logo on screen and on bills
    (Settings → Business details).
  • New look: shop name and titles in Cinzel capitals, text in Montserrat. A welcome screen
    with your shop name, date and today's bill count before login, and a Home screen after
    login: today's sales, cash, dues, quick start buttons and what needs attention
    (cashiers see only their own bills).
  • Forgot the owner PIN? On the main computer: login screen → "Forgot owner PIN?" → use the
    online-backup recovery code, or a one-time code from Elite Kaiiser.

────────────────────────────────────────
10. NEW IN 2.0
────────────────────────────────────────
  • Split payment: on the bill press Split and enter how much came by Cash, UPI and Card.
    Anything left is kept as the customer's balance. Reports, cash book and accounts show
    each part under its own mode.
  • Exchange in one step: open the bill → Return items → "Exchange — customer takes other
    items now". The new bill opens with the returned value already counted; it shows what to
    collect now (or what to give back).
  • Go to anything: press Ctrl+K (or "Go to…" at the top of the menu) and type a screen, an
    item, a customer or a bill number.
  • Touch billing: press Touch on the bill screen for big item buttons by category.
  • Settings are now in tabs (Shop & licence, Billing, Printing, Staff, Branches & online,
    Backup & data). Pick your type of shop there; things your kind of shop does not use are
    hidden, and you can switch them back on.
  • Packages: your licence shows its package (Starter, Professional, Business or
    Enterprise), how many counters, staff logins, branches and godowns it allows, and what
    a bigger package adds. Licences bought before 2.0 keep everything they had.
  • When a licence ends there are now grace days (usually 7) with a red "renew" warning
    before new bills stop. Your data always stays viewable, printable and exportable.
  • The free trial is now 30 days.
  • 2.0.1: on an exchange paid in cash, the customer screen now shows the right change;
    the item count on the bill is in Gujarati / Hindi too.
  • 2.0.2: the red "pick a customer" warning now shows only while something is left unpaid.

────────────────────────────────────────
11. NEW IN 2.1 — ORDERS ON WHATSAPP
────────────────────────────────────────
  • Pay now: Online orders → Settings → "Customers can pay now by UPI". After ordering, the
    customer's page shows "Pay ₹… by UPI" (opens GPay, PhonePe, Paytm…) with the exact amount
    and the order number. Money goes to the UPI ID in Settings → Shop — a business / merchant
    UPI ID works best. You can also add a payment link (e.g. razorpay.me) for cards.
  • The customer taps "I have paid" and can type the UPI reference. TezBooks rings, the order
    shows "Says paid — check". Check your UPI / bank app, then press "Money received" — the
    customer's page shows "Payment received". Bills made from paid orders are marked UPI.
  • Delivery times: type your slots (e.g. 10am–1pm, 4pm–8pm); customers pick today or tomorrow.
  • Customers can add their location; the order has "Open the customer's location on the map".
  • WhatsApp kit (Online orders → WhatsApp kit):
      - Auto-reply: a ready message with your order link for WhatsApp Business → Greeting
        message and Away message, so every new chat gets your menu.
      - Price list: today's prices by category, to copy or send on WhatsApp / Status.
      - Paste an order: paste a list a customer typed ("2 kg sugar", "Maggi x 4") → check the
        items → Make bill. A phone number in the message picks the customer.

────────────────────────────────────────
NEW IN 1.9
────────────────────────────────────────
  • Gujarati and Hindi: pick the language at the bottom of the menu. Every screen, button,
    message and help text changes; each counter can use its own language. Item and customer
    names stay as you typed them.
  • Printed bills in Gujarati or Hindi: Settings → Billing rules → Bill language. Choose
    English with Gujarati/Hindi under each label (recommended for GST bills), or fully
    Gujarati/Hindi. The amount in words stays in English.

────────────────────────────────────────
NEW IN 1.8
────────────────────────────────────────
  • Purchase orders: Suppliers → New purchase order (or Inventory → Reorder list). TezBooks
    suggests what to order — items running low, enough for 15 days of sales (change in
    Settings) — grouped by the supplier you last bought each item from, with last rates.
    Send the order on WhatsApp or print it. When goods come, press "Goods arrived → Stock
    in"; part deliveries are tracked until everything arrives.
  • Send offers on WhatsApp: Customers → Send offer. Pick a group (everyone, customers with
    points, not seen for 30 days, top spenders, wholesale), write the message once, send one
    tap per customer. Customers can be marked "does not want offer messages".
  • Owner's phone app now shows online orders, every branch side by side, and purchase
    orders waiting for goods.

────────────────────────────────────────
NEW IN 1.7
────────────────────────────────────────
  • Bills on WhatsApp as a link: the customer opens the full bill on their phone, saves it as
    PDF and pays the balance by UPI in one tap. Udhaar reminders carry a link listing all
    unpaid bills with a "Pay by UPI" button. Links are locked — only someone with the link
    can read the bill. (Settings → Bills on WhatsApp)
  • UPI at the counter: when a bill is UPI, a QR for the exact amount opens on the screen;
    press "Payment received" to save, or "Not paid — give udhaar". (Settings → UPI bills)
  • GSTR-1 file for the GST portal: Reports → GST & accounts → GSTR-1 file for the portal.
    Pick the month, check the list, upload at Returns → GSTR-1 → Prepare offline. Includes
    the B2B / B2C HSN summary and documents issued. GSTR-3B summary now also shows table
    3.2 (sales to unregistered buyers in other states).

────────────────────────────────────────
NEW IN 1.6
────────────────────────────────────────
  • Branches: run TezBooks at every shop of your business and keep them in step over the
    internet (Settings → Branches). Items, prices, customers, udhaar, suppliers and offers
    are shared; each shop sells from its own stock and has its own bill numbers. Send stock
    to another shop (Inventory → Transfer) — it is added there when they press Received.
    Reports → All branches shows every shop side by side. Everything is locked with your
    business key before it leaves the computer.
  • Online orders: your own order page, tezbooks.com/o/your-shop (Online orders in the menu).
    Customers order on their phone for home delivery or pickup and pay cash or UPI when they
    get it. New orders ring at the counter; accept, make the bill in one tap, and send
    updates on WhatsApp. Set delivery charge, free delivery above, minimum order, and pause
    any time. Hide an item: Products → item → Online orders page → Hide.

────────────────────────────────────────
NEW IN 1.5
────────────────────────────────────────
  1.5.1: download the free trial from tezbooks.com; quote requests from the website reach
         Elite Kaiiser directly.
  • TezBooks Setup window (main computer or another counter).
  • Printers: find printers, choose a printer for bills, A4 and labels, print without a window.
  • Three A4 bill layouts; long bills continue neatly onto more pages.
  • Email bills as PDF from your own email; Save PDF.
  • Updates over the internet, checked and installed by themselves.

Mac:  use TezBooks-AppleSilicon (M1/M2/M3) or TezBooks-Intel.
      First time: right-click → Open. Data: ~/Library/Application Support/TezBooks
Linux: ./tezbooks      Data: ~/.tezbooks

© Elite Kaiiser. All rights reserved.
